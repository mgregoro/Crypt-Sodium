Crypt-Sodium version 0.09
=========================

Simple wrapper around NaCL functions as provided by libsodium.  crypto_box, crypto_stream, crypto_hash,
and crypto_sign are all present and accounted for.  None of the specific implementations are exposed,
only the default implementations are, so please refer to your version of libsodium's release notes if 
you need to know what implementation you are using.

INSTALLATION

To install this module type the following:

   perl Makefile.PL
   make
   make test
   make install

DEPENDENCIES

This module requires these other modules and libraries:

  libsodium (download.libsodium.org/libsodium/releases/)

COPYRIGHT AND LICENCE

Copyright (C) 2016 by Michael Gregorowicz

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.0 or,
at your option, any later version of Perl 5 you may have available.

